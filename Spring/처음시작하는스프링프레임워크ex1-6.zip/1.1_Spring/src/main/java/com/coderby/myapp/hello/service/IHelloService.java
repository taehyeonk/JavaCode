package com.coderby.myapp.hello.service;

public interface IHelloService {
	String sayHello(String name);
}
