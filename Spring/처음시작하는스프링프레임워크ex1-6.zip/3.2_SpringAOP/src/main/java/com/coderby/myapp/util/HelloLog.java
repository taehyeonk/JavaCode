package com.coderby.myapp.util;

public class HelloLog {
	public static void log() {
		System.out.println(">>>LOG<<< : " + new java.util.Date());
	}
}
